<template>
<p>CBOTACT {{counter}}</p>
<button @click="increment()">Click</button>
</template>

<script>
export default {
    data() {
        return {
            counter: 0
        }
    },
    methods: {
        increment() {
            this.counter++;
        }
    },
    mounted() {
        console.log("MOUNTED");
    },
    beforeCreate() {
        console.log("BEFORE CREATE");
    },
    created() {
        console.log("CREATED");
    },
    beforeMount() {
        console.log("BEFORE MOUNT");
    },
    beforeUpdate() {
        console.log("BEFORE UPDATE");
    },
    updated() {
        console.log("UPDATED");
    },
    beforeUnmount() {
        console.log("BEFORE UN MOUNT");
    },
    unmounted() {
        console.log("UN MOUNTED");
    }
}
</script>